﻿namespace Kitaplik_Mvc.Models
{
    public static class UserRoles
    {
        public const string Role_Admin = "Admin";

        public const string Role_Ogrenci = "Ogrenci";
    }
}
